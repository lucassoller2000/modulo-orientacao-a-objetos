package ResidentEvil.Municoes;

public class MunicaoCalibre12 extends Municao{
    public MunicaoCalibre12() {
        super("MunicaoCalibre12", 2, 1, 0.4, 8);
    }
}
