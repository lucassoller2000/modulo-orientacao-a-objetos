package ResidentEvil.Municoes;

public class MunicaoTresOitao extends Municao {
    public MunicaoTresOitao() {
        super("MunicaoTresOitao", 2, 1, 0.5, 20);
    }
}
