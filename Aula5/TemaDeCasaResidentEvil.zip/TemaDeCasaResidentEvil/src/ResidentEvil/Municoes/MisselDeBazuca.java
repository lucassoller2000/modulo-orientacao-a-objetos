package ResidentEvil.Municoes;

import ResidentEvil.Item;

public class MisselDeBazuca extends Item {
    public MisselDeBazuca() {
        super("MisselDeBazuca", 2, 8, 15);
    }
}
