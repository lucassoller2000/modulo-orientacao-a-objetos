package ResidentEvil.Armas;

public class TresOitao extends Arma {

    public TresOitao() {
        super("TresOitao", 3, 2, 6, 8,1);
    }
}
