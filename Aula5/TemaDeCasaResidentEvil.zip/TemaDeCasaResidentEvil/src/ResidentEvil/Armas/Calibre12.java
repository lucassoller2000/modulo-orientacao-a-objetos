package ResidentEvil.Armas;

public class Calibre12 extends Arma {
    public Calibre12() {
        super("Calibre12", 3, 7, 8, 2,2);
    }
}
